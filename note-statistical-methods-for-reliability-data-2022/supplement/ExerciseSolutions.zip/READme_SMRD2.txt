The authors of SMRD2 have written solutions for a substantial number
of the end-of-chapter exercises in SMRD2. A pdf file containing this
collection of solutions will be made available to instructors who
adopt SMRD2 for their courses. Instructions can be found at the Wiley Book
Companion Website at https://www.wiley.com/go/meeker/reliability2e. 
