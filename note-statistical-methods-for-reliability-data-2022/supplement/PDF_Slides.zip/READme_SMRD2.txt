The authors of SMRD2 have written slide presentations for each chapter
of the book.  The pdf files are in this folder.

See also SMRD2_SubsetSlides.