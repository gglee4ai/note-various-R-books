#!/bin/bash

# Removing old files to start clean
rm -r PS_subset_FullSize
rm -r PS_subset_Multiple

#Create folders to hold the slide ps files
mkdir PS_subset_FullSize
mkdir PS_subset_Multiple
#
# make the subset ps files
#
ShellScripts/MakeSubsets.sh
echo "Finished"
