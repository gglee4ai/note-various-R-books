#!/bin/bash

#
# Removing old folders and files
#
rm  Merged_subsets_FullSize.pdf
rm  Merged_subsets_Multiple.pdf
rm -r PDF_subset_FullSize
rm -r PDF_subset_Multiple
#
#Create needed folders
#
mkdir PS_subset_FullSize
mkdir PS_subset_Multiple
mkdir PDF_subset_FullSize
mkdir PDF_subset_Multiple
#
# make the subset ps files
#
ShellScripts/MakeSubsets.sh
#
# make the subset pdf files
#
ShellScripts/MakeSubsetsPdfs.sh
ShellScripts/MergeSubsetsPdfs.sh
#
echo "Removing the temporary folders"
rm -r PS_subset_FullSize
rm -r PS_subset_Multiple
echo "Finished"
