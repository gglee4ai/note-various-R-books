# Modified 4/17/2021
idsubfull=subset_FullSize
idsubmultiple=subset_Six-to-a-page
perpage=6
#
#
echo '****************'  doing Chapter$2       '****************'
echo 'Prefix' $1
echo 'Pages:'  $3
psselect $3  $1PS_FullSize/Chapter$2"_FullSize.ps" $1PS_subset_FullSize/Chapter$2_"$idsubfull".ps
psnup -l -d -n $perpage -pletter $1PS_subset_FullSize/Chapter$2_"$idsubfull".ps > $1PS_subset_Multiple/Chapter$2_"$idsubmultiple".ps


# make into DOS format file (needed by acrobat)

    #strip out the ^M
#

tr -d ""  < $1PS_subset_FullSize/Chapter$2_"$idsubfull".ps > $1PS_subset_FullSize/xxxtmpxxx

mv $1PS_subset_FullSize/xxxtmpxxx $1PS_subset_FullSize/Chapter$2_"$idsubfull".ps
