#
#
# Single file containing all the subsets requested in file "merge.fullsize.txt"
#
echo "Merging the pdfs from the subsets. Fullsize slides"
#
gswin64c -dBATCH -dNOPAUSE -q -sDEVICE=ps2write -sOutputFile=PS_subset_FullSize.ps PS_subset_FullSize/*.ps
ps2pdf PS_subset_FullSize.ps
rm PS_subset_FullSize.ps
mv PS_subset_FullSize.pdf Merged_subsets_FullSize.pdf
#
# Single file containing all the subsets requested in file "merge.multiple.txt"
#
echo "Merging the pdfs from the subsets. Multiple slides per page"
gswin64c -dBATCH -dNOPAUSE -q -sDEVICE=ps2write -sOutputFile=PS_subset_Multiple.ps PS_subset_Multiple/*.ps
ps2pdf PS_subset_Multiple.ps
rm PS_subset_Multiple.ps
mv PS_subset_Multiple.pdf Merged_subsets_Multiple.pdf
