#SubsetsSlides
#must have a defined environmental variable $SubsetHome

#
SubsetHome=C:/Users/wqmeeker/Documents/SMRD2_SubsetSlides
SubsetLoc=$SubsetHome/
#
#

echo This is the path to the full and subset .ps files: $SubsetLoc


ShellScripts/mkone.sh $SubsetLoc      01  '-p1,2,5,12,13,16,18-19'
ShellScripts/mkone.sh $SubsetLoc      02  '-p1,2,4,6,7,9,24,26'
ShellScripts/mkone.sh $SubsetLoc      03  '-p1,2,18,17,19,36,39,43'
ShellScripts/mkone.sh $SubsetLoc      04  '-p1,2,17,16,18,22,21,24'
#ShellScripts/mkone.sh $SubsetLoc      05  '-p1,2,7-10,15-18'
ShellScripts/mkone.sh $SubsetLoc      06  '-p1,2,4,10,11,14,20-22,24-26,31,32,35-39'
#ShellScripts/mkone.sh $SubsetLoc      07  '-p2,4-11,13-20,22-24,26-30'
ShellScripts/mkone.sh $SubsetLoc      08  '-p1,2,4-10,13-16,22,23,24,34-37,40-46,50-52'
#ShellScripts/mkone.sh $SubsetLoc      09  '-p2,4-7,9-22,24-32,34-43,45-52,54-59'
ShellScripts/mkone.sh $SubsetLoc      10  '-p1,2,4-7,19,20,22,24-27,38-40,57'
ShellScripts/mkone.sh $SubsetLoc      11  '-p1,2,16-20,34-35,40,42'
ShellScripts/mkone.sh $SubsetLoc      12  '-p1-2,5,6,18-21,24,25-27'
ShellScripts/mkone.sh $SubsetLoc      13  '-p1,2,4,6,7,8,12-13,15-16,22-45,47'
ShellScripts/mkone.sh $SubsetLoc      14  '-p1,2,4,5,13-16,21-26'
ShellScripts/mkone.sh $SubsetLoc      15  '-p1,2,43-45,50,60-63'
ShellScripts/mkone.sh $SubsetLoc      16  '-p1,2,9-16,21-27,29'
ShellScripts/mkone.sh $SubsetLoc      17  '-p1,2,8,16-24,33-48'
ShellScripts/mkone.sh $SubsetLoc      18  '-p1,2,7-13,15,16,18-21,33-38,40-43,45-52,56-60'
ShellScripts/mkone.sh $SubsetLoc      19  '-p1,2,4-6,8,12-14,17,18,20-23,43-52,55-57,59-65'
ShellScripts/mkone.sh $SubsetLoc      20  '-p1,2,4-9,11,14-19,21,24-31,39,40,43-47,51,53-55,57,58,67,68,70,72-76,78-79,81,85-86,88'
ShellScripts/mkone.sh $SubsetLoc      21  '-p1,2,5-9,11-14,17,19,20,22,24,36-39,41-47,49-51'
ShellScripts/mkone.sh $SubsetLoc      22  '-p1,2,5-7,16-21,30-33,35-38,40'
#ShellScripts/mkone.sh $SubsetLoc      22  '-o -e'
