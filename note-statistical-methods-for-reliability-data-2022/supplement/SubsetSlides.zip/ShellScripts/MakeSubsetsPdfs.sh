#
echo "Creating pdfs for subset. Fullsize slides"
#
# Making subset per chapter. Pdf fullsize (one slide per page)
#
cd  PS_subset_FullSize
#
#
for f in *.ps; do
	ps2pdf "$f"  "../PDF_subset_FullSize/${f%.*}.pdf"
done
#
# Making subset per chapter. Pdf Multiple (six slides per page)
#
echo "Creating pdfs for subset. Multiple slides per page"
#
cd ../PS_subset_Multiple
#
for f in *.ps; do
	ps2pdf "$f"  "../PDF_subset_Multiple/${f%.*}.pdf"
done
#
