This folder contains R packages containing functions used in SMRD2. These are:


R package bootSMRD contains the file
ShockAbsorberWeibullBootstrapResults.csv which contains the
parametric bootstrap draws from the Shock Absorber example in
Chapter 9. File SMRD2_verbatimChapter09.R containes the example R
commands used in all of the examples in Chapter 9 of SMRD2. There
are four exported functions in bootSMRD that facilitate the
computation of the different kinds of bootstrap confidence intervals
that are described and illustrated in Chapter 9. A fifth visible
function provides the path to the
ShockAbsorberWeibullBootstrapResults.csv draws file.

R package lsinf provide functions for most of the examples in
Chapter 13. File SMRD2_verbatim13.R containes the example R
commands used in most of the examples in Chapter 9 of SMRD2. The
simulation planning examples require R package RSplida (see below)

R package StatInt contains, among other things, function to compute
probabilities and quantiles for some distributions not supported in
R. This package was originally written to provide toools to do the
examples in the book Statistical Intrvals by Meeker, Escobar, and
Hahn (2017) but is needed for some of the examples in SMRD2.

There are two versions of each package here. The .zip file works on
Windows and the .tar.grz file works on any platform, but requires
RTools for Windows.

R package poibin is available on CRAN.

R package RSplida was used to do almost all of the examples in
SMRD2. The latest Windows version of RSplida can be obtained from
the following link. There is no formal documentation for RSplida,
but the RSplida_echaptersSMRD2 folders (one for each chapter) in the
package contains run files that were used for the examples in the
book.

https://wqmeeker.stat.iastate.edu/RSplida.zip


