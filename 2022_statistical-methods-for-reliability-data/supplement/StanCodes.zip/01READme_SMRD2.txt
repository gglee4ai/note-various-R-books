This folder contains Stan model files used in SMRD2.
